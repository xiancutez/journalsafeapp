//
//  signup.swift
//  Safe
//
//  Created by Administrator on 12/05/2018.
//  Copyright © 2018 Assignment2. All rights reserved.
//

import UIKit

class signup: UIViewController {

    
    @IBOutlet weak var match: UILabel!
    
    @IBOutlet weak var newusername: UITextField!
    
    
    @IBOutlet weak var newpassword: UITextField!
    
    @IBOutlet weak var newverifypassword: UITextField!
    
    //Sign up function
    @IBAction func signupsubmit(_ sender: Any) {
        
        UserDefaults.standard.removePersistentDomain(forName: Bundle.main.bundleIdentifier!)


        let usr = newusername.text
        let pass1 = newpassword.text
        let pass2 = newverifypassword.text
        
        print(usr)
        print(pass1)
        
        if pass1 != pass2 || pass1 == "" || pass2 == "" {
            if pass1 != pass2 {
            match.isHidden = false
            }
            if pass1 == "" || pass2 != "" {
                
            }
            
        } else {
            
            
            //New user details
            let sep = "gshacghdcagsdgghvasghvgvhavhdgagv"
            let usrdet = usr! + sep + pass1!
            
            
            var originaldef = String(describing: UserDefaults.standard.string(forKey: "usersx"))
            originaldef = originaldef.replacingOccurrences(of: "\\", with: "")
            originaldef = originaldef.replacingOccurrences(of: "Optional", with: "")
            originaldef = originaldef.replacingOccurrences(of: "\"", with: "")
            originaldef = originaldef.replacingOccurrences(of: "(", with: "")
            originaldef = originaldef.replacingOccurrences(of: ")", with: "")
            
            if originaldef == "nil" {

                originaldef = ""
            }
            
            
            print("will work")
            print(originaldef)
            
            var arr1 = originaldef.components(separatedBy: "uyyuqbieuyfyqfvyteftyqwbtfqyqwe")
            
            arr1.append(usrdet)
            
            var arrstr = arr1.joined(separator:"uyyuqbieuyfyqfvyteftyqwbtfqyqwe")
            
            print(arrstr)
            
            arrstr = arrstr.replacingOccurrences(of: "\\", with: "")
            arrstr = arrstr.replacingOccurrences(of: "Optional", with: "")
            arrstr = arrstr.replacingOccurrences(of: "\"", with: "")
            arrstr = arrstr.replacingOccurrences(of: ")", with: "")
            arrstr = arrstr.replacingOccurrences(of: "(", with: "")
            UserDefaults.standard.set(arrstr, forKey: "usersx")
            
        }
        
        
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
