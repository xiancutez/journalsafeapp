//
//  addnewlog.swift
//  Safe
//
//  Created by Administrator on 12/05/2018.
//  Copyright © 2018 Assignment2. All rights reserved.
//

import UIKit

class addnewlog: UIViewController {

    @IBOutlet weak var textarealog: UITextView!
    
    
    //Submit new entry
    @IBAction func submitlog(_ sender: Any) {
        
        let log = textarealog!.text
        
        let sep = "QWgfbsadasdwdcwrcgwvervregrg"
        
        //New user details
        let str = log! + sep + userloggedin
        
        
        
        
        var originaldef = String(describing: UserDefaults.standard.string(forKey: "logs"))
        originaldef = originaldef.replacingOccurrences(of: "\\", with: "")
        originaldef = originaldef.replacingOccurrences(of: "Optional", with: "")
        originaldef = originaldef.replacingOccurrences(of: "\"", with: "")
        originaldef = originaldef.replacingOccurrences(of: "(", with: "")
        originaldef = originaldef.replacingOccurrences(of: ")", with: "")
        
        if originaldef == "nil" {
            
            originaldef = ""
        }
        
        
        print("will work")
        print(originaldef)
        
        var arr1 = originaldef.components(separatedBy: "uyyuqbieuyfyqfvyteftyqwbtfqyqwe")
        
        //Append to array
        arr1.append(str)
        
        var arrstr = arr1.joined(separator:"uyyuqbieuyfyqfvyteftyqwbtfqyqwe")
        
        print(arrstr)
        
        arrstr = arrstr.replacingOccurrences(of: "\\", with: "")
        arrstr = arrstr.replacingOccurrences(of: "Optional", with: "")
        arrstr = arrstr.replacingOccurrences(of: "\"", with: "")
        arrstr = arrstr.replacingOccurrences(of: ")", with: "")
        arrstr = arrstr.replacingOccurrences(of: "(", with: "")
        
        //Save new entry
        UserDefaults.standard.set(arrstr, forKey: "logs")
        
        
        
    }
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
