//
//  showlogs.swift
//  Safe
//
//  Created by Administrator on 12/05/2018.
//  Copyright © 2018 Assignment2. All rights reserved.
//

import UIKit

class showlogs: UIViewController {

    @IBOutlet weak var scrollviewlogs: UIScrollView!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

       //Numbering
        var num = 1
        
        // Scrollview visuals editing
        scrollviewlogs.layer.cornerRadius = 3.5
        scrollviewlogs.layer.masksToBounds = true
        scrollviewlogs.isScrollEnabled = true
        
        
        //Log retrival
        var originaldef = String(describing: UserDefaults.standard.string(forKey: "logs"))
        
        print(originaldef)
        
        originaldef = originaldef.replacingOccurrences(of: "\\", with: "")
        originaldef = originaldef.replacingOccurrences(of: "Optional", with: "")
        originaldef = originaldef.replacingOccurrences(of: "\"", with: "")
        originaldef = originaldef.replacingOccurrences(of: ")", with: "")
        originaldef = originaldef.replacingOccurrences(of: "(", with: "")
        
        var arr1 = originaldef.components(separatedBy: "uyyuqbieuyfyqfvyteftyqwbtfqyqwe")
        
        var currentheight = 40

        for (index,element) in arr1.enumerated() {
            
            
            originaldef = originaldef.replacingOccurrences(of: "\\", with: "")
            originaldef = originaldef.replacingOccurrences(of: "Optional", with: "")
            originaldef = originaldef.replacingOccurrences(of: "\"", with: "")
            originaldef = originaldef.replacingOccurrences(of: ")", with: "")
            originaldef = originaldef.replacingOccurrences(of: "(", with: "")
            
            
            if element != "nil" && element != "" {
                var arr2 = element.components(separatedBy: "QWgfbsadasdwdcwrcgwvervregrg")
                
                print(arr2[0]) //Log
                print(arr2[1]) //User
                
                
                //Check if it is user who is logged in
                if arr2[1] == userloggedin {
        
        // Do any additional setup after loading the view.
        let ghu = scrollviewlogs.frame.width - 40
        let ghuxc = scrollviewlogs.frame.width
        let dynamicLabel = UILabel(frame: CGRect(x: 40, y: currentheight, width: Int(ghu)-10, height: 30))
        dynamicLabel.textColor = UIColor.white
        dynamicLabel.textAlignment = NSTextAlignment.left
        dynamicLabel.text = String(num) + ". " + arr2[0]
        
        num = num + 1
                    
        dynamicLabel.numberOfLines = 0
        
        dynamicLabel.sizeToFit()
        
        scrollviewlogs.addSubview(dynamicLabel)
        
        
        let meheight = dynamicLabel.frame.height
        let meheightlocal = Int(meheight)
        currentheight = currentheight + Int(meheight) + 30
                    
                    scrollviewlogs.contentSize = CGSize(width: Int(scrollviewlogs.frame.size.width), height: currentheight)

        
                }
            }
        }
        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
