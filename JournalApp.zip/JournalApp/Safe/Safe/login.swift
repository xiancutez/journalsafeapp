//
//  login.swift
//  Safe
//
//  Created by Administrator on 12/05/2018.
//  Copyright © 2018 Assignment2. All rights reserved.
//

import UIKit
import AVFoundation


var userloggedin: String = String()

class login: UIViewController {

    @IBOutlet weak var username: UITextField!
    
    @IBOutlet weak var password: UITextField!
    

    
    //Login process checks user defaults for any relevant login details
    @IBAction func loginsubmit(_ sender: Any) {
        
        var originaldef = String(describing: UserDefaults.standard.string(forKey: "usersx")) //Data Retrival
        
        print(originaldef)

        originaldef = originaldef.replacingOccurrences(of: "\\", with: "")
        originaldef = originaldef.replacingOccurrences(of: "Optional", with: "")
        originaldef = originaldef.replacingOccurrences(of: "\"", with: "")
        originaldef = originaldef.replacingOccurrences(of: ")", with: "")
        originaldef = originaldef.replacingOccurrences(of: "(", with: "")
        
        var arr1 = originaldef.components(separatedBy: "uyyuqbieuyfyqfvyteftyqwbtfqyqwe")
        
        
        for (index,element) in arr1.enumerated() {
            

            //String cleanse
            originaldef = originaldef.replacingOccurrences(of: "\\", with: "")
            originaldef = originaldef.replacingOccurrences(of: "Optional", with: "")
            originaldef = originaldef.replacingOccurrences(of: "\"", with: "")
            originaldef = originaldef.replacingOccurrences(of: ")", with: "")
            originaldef = originaldef.replacingOccurrences(of: "(", with: "")

            
            if element != "nil" && element != "" {
            var arr2 = element.components(separatedBy: "gshacghdcagsdgghvasghvgvhavhdgagv") //Array creation
            
            print(arr2[0]) //Password
            print(arr2[1]) //Username
            
            if arr2[0] == username!.text && arr2[1] == password!.text {
                userloggedin = arr2[0]
                let storyboard = UIStoryboard(name: "Main", bundle: nil)
                let controller = storyboard.instantiateViewController(withIdentifier: "mainmenu")
                self.present(controller, animated: false, completion: nil)
                print("successful")
            } else {
                
                print("unsuccessful")
            }
            }
            
        }
        
        
        
        
    }
    
    var player: AVAudioPlayer?
    
    
    //Background music
    func playSound() {
        guard let url = Bundle.main.url(forResource: "background", withExtension: "mp3") else { return }
        
        do {
            try AVAudioSession.sharedInstance().setCategory(AVAudioSessionCategoryPlayback)
            try AVAudioSession.sharedInstance().setActive(true)
            
            
            
            /* The following line is required for the player to work on iOS 11. Change the file type accordingly*/
            player = try AVAudioPlayer(contentsOf: url, fileTypeHint: AVFileType.mp3.rawValue)
            
            /* iOS 10 and earlier require the following line:
             player = try AVAudioPlayer(contentsOf: url, fileTypeHint: AVFileTypeMPEGLayer3) */
            
            guard let player = player else { return }
            
            player.play()
            
        } catch let error {
            print(error.localizedDescription)
        }
    }
    

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        
      //Background music trigger
        playSound()
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
